document.getElementById('showCard1').addEventListener('click', function() {
    document.getElementById('cardContainer1').style.display = 'block';
  });
  
  function closeCard1() {
    document.getElementById('cardContainer1').style.display = 'none';
  }

  
  document.getElementById('showCard2').addEventListener('click', function() {
    document.getElementById('cardContainer2').style.display = 'block';
  });
  function closeCard2() {
    document.getElementById('cardContainer2').style.display = 'none';
  }

  
  document.getElementById('showCard3').addEventListener('click', function() {
    document.getElementById('cardContainer3').style.display = 'block';
  });
  function closeCard3() {
    document.getElementById('cardContainer3').style.display = 'none';
  }
  
  document.getElementById('showCard4').addEventListener('click', function() {
    document.getElementById('cardContainer4').style.display = 'block';
  });
  function closeCard4() {
    document.getElementById('cardContainer4').style.display = 'none';
  }